# AI-Assisted False Positive Detection for Surveillance Alerts

## 1. Executive Summary

### Problem

The existing surveillance platform processes communications from multiple channels such as Outlook, Webex, Bloomberg email/chat and other sources. Existing policies, keywords and rules generate surveillance alerts.

At high volume, many alerts are false positives because a keyword can appear in an innocent context.

Example:

> "Please complete the mandatory insider trading compliance training."

The existing rule may trigger on `insider trading`, even though the communication is a compliance/training message.

The proposed AI layer evaluates **only existing alerts**. It does not replace the current surveillance engine.

### Goal

Reduce the number of alerts that require manual business review while preserving evidence, auditability and a human-review path for uncertain cases.

The initial architecture deliberately does **not** use embeddings or a vector database. Semantic interpretation is delegated to the LLM after inexpensive deterministic duplicate reduction and context extraction.

---

# 2. Design Goals

1. Process approximately 1M alerts/day.
2. Support multiple communication channels.
3. Support up to approximately 50 policies.
4. Reduce duplicate/near-duplicate messages before LLM processing.
5. Minimize LLM input/output token usage.
6. Batch messages by policy while respecting model token limits.
7. Produce structured and auditable AI results.
8. Route uncertain cases to business reviewers.
9. Preserve the original alert and duplicate relationships.
10. Make model/provider replacement possible through an internal LLM gateway.
11. Allow future optimization using human review data.
12. Keep the first implementation simple: Python + relational DB + queue/stream + LLM API.

---

# 3. Non-Goals

The system is not intended initially to:

- replace the existing surveillance/rule engine;
- scan every communication in the enterprise;
- use an embedding model for semantic search;
- make a final compliance/legal determination;
- automatically suppress all alerts based only on LLM confidence;
- train a custom model before sufficient historical labels exist.

---

# 4. End-to-End Architecture

```mermaid
flowchart TD
    A["Communication Sources<br/>Outlook / Webex / Bloomberg / Other"]
    B["Existing Surveillance Engine<br/>Policies + Rules + Keywords"]
    C["Alert Ingestion"]
    D["Alert Normalization"]
    E["Group / Partition by Policy"]
    F["Exact Duplicate Detection"]
    G["Template / Near-Duplicate Detection"]
    H["Representative Alert Selection"]
    I["Context Extraction"]
    J["Token & Context Optimization"]
    K["Policy-Aware Batch Manager"]
    L["LLM Gateway"]
    M["Policy-Aware LLM"]
    N["Structured Result Validation"]
    O["Decision Service"]
    P["High Confidence FP<br/>Recommendation"]
    Q["High Confidence TP<br/>Priority Review"]
    R["Uncertain / Low Confidence<br/>Human Review"]
    S["Results + Audit DB"]
    T["Business Review UI"]
    U["Human Decision"]
    V["Metrics / Monitoring"]
    W["Policy / Prompt / Model Configuration"]

    A --> B
    B --> C
    C --> D
    D --> E
    E --> F
    F --> G
    G --> H
    H --> I
    I --> J
    J --> K
    K --> L
    L --> M
    M --> N
    N --> O

    O --> P
    O --> Q
    O --> R

    P --> S
    Q --> S
    R --> T
    T --> U
    U --> S

    S --> V
    W --> K
    W --> L
    W --> M
    V -.-> W
```

---

# 5. Step 1 — Existing Surveillance Alert Ingestion

The existing surveillance platform remains the source of truth for **which communication generated an alert**.

The AI system receives an alert event rather than every communication.

## Input

A normalized source event should contain, where available:

```json
{
  "alert_id": "A12345",
  "message_id": "M98765",
  "channel": "OUTLOOK",
  "policy_id": "POLICY_001",
  "policy_name": "INSIDER_TRADING",
  "alert_text": "insider trading",
  "full_message": "...",
  "subject": "RE: Earnings discussion",
  "sender": "employee@example.com",
  "recipients": ["employee2@example.com"],
  "timestamp": "2026-09-22T10:30:00Z",
  "alert_start_offset": 1250,
  "alert_end_offset": 1265
}
```

Not every source will provide every field.

## Important

If possible, ask the upstream surveillance system to provide:

```text
alert_start_offset
alert_end_offset
```

or:

```text
paragraph_id
sentence_id
```

This makes context extraction significantly more reliable.

## Channel handling

Channel should **not** be the primary classification dimension.

The same policy can be applied to:

```text
Outlook
Webex
Bloomberg
```

However, retain channel metadata because later analytics may reveal channel-specific false-positive patterns.

---

# 6. Step 2 — Alert Normalization

Different source systems may produce different structures.

Create one canonical Python model.

Example:

```python
from pydantic import BaseModel
from typing import Optional


class Alert(BaseModel):
    alert_id: str
    message_id: str
    policy_id: str
    channel: str

    alert_text: str
    full_message: str

    subject: Optional[str] = None

    alert_start_offset: Optional[int] = None
    alert_end_offset: Optional[int] = None

    timestamp: Optional[str] = None

    metadata: dict = {}
```

The downstream pipeline should operate on this canonical representation.

## Why?

Without normalization:

```text
Outlook -> special logic
Webex -> special logic
Bloomberg -> special logic
```

becomes difficult to maintain.

Instead:

```text
Outlook ----\
Webex -------\
Bloomberg ----> Canonical Alert
Other --------/
```

---

# 7. Step 3 — Group Alerts by Policy

Example:

```text
1,000 alerts

POLICY_1 = 200
POLICY_2 = 500
POLICY_3 = 150
POLICY_4 = 100
POLICY_5 = 50
```

Process each policy independently.

```mermaid
flowchart LR
    A["1,000 Alerts"] --> B["Group by policy"]

    B --> P1["Policy 1<br/>200"]
    B --> P2["Policy 2<br/>500"]
    B --> P3["Policy 3<br/>150"]
    B --> P4["Policy 4<br/>100"]
    B --> P5["Policy 5<br/>50"]

    P1 --> D1["Duplicate + Context + LLM"]
    P2 --> D2["Duplicate + Context + LLM"]
    P3 --> D3["Duplicate + Context + LLM"]
    P4 --> D4["Duplicate + Context + LLM"]
    P5 --> D5["Duplicate + Context + LLM"]
```

## Why policy grouping is important

The LLM needs to understand:

```text
What policy was triggered?
What does the policy mean?
What evidence makes it relevant?
```

A policy-specific batch gives consistent context.

---

# 8. Step 4 — Exact Duplicate Detection

This is the cheapest reduction layer.

## Problem

The same message can arrive multiple times because of:

- multiple ingestion paths;
- repeated alert generation;
- duplicate copies;
- multiple recipients;
- system retries.

Example:

```text
Message A:
Please complete the Insider Trading training.

Message B:
Please complete the Insider Trading training.
```

## Approach

Normalize the text and calculate SHA-256.

```mermaid
flowchart TD
    A["Incoming Alert"] --> B["Extract comparison text"]
    B --> C["Normalize text"]
    C --> D["SHA-256 hash"]
    D --> E{"Hash exists?"}

    E -->|Yes| F["Existing duplicate group"]
    E -->|No| G["Create new duplicate group"]

    F --> H["Mark as duplicate"]
    G --> I["Mark as representative"]

    H --> J["Persist relationship"]
    I --> J
```

## Normalization

Possible operations:

- lowercase;
- normalize whitespace;
- normalize Unicode;
- remove HTML tags;
- normalize line endings;
- remove known system footers;
- remove known tracking information.

Example:

```python
import hashlib
import re
import unicodedata


def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    text = text.lower()
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def generate_hash(text: str) -> str:
    normalized = normalize_text(text)
    return hashlib.sha256(
        normalized.encode("utf-8")
    ).hexdigest()
```

## Important

Do not necessarily hash the entire raw email.

Email headers, signatures, timestamps and footers can make identical business content look different.

Define a **comparison representation**.

---

# 9. Step 5 — Template / Near-Duplicate Detection

This is especially important for bulk HR communications.

## Example

Message A:

```text
Dear John,

Please complete your Insider Trading training
before 15 September.

Regards,
HR
```

Message B:

```text
Dear Sarah,

Please complete your Insider Trading training
before 20 September.

Regards,
HR
```

These messages are not exact duplicates.

But operationally they are the same template.

## Step 5.1 — Mask dynamic values

Transform:

```text
John
Sarah
```

into:

```text
<PERSON>
```

Transform:

```text
15 September
20 September
```

into:

```text
<DATE>
```

Transform:

```text
john@company.com
```

into:

```text
<EMAIL>
```

Potential dynamic values:

- person names;
- dates;
- timestamps;
- email addresses;
- URLs;
- employee IDs;
- ticket IDs;
- numeric identifiers;
- generated message IDs.

## Template example

```text
Dear <PERSON>,

Please complete your Insider Trading training
before <DATE>.

Regards,
HR
```

Then generate a hash.

```mermaid
flowchart TD
    A["Message"] --> B["Basic normalization"]
    B --> C["Detect dynamic values"]
    C --> D["Mask dynamic values"]
    D --> E["Template representation"]
    E --> F["SHA-256"]
    F --> G{"Template hash exists?"}

    G -->|Yes| H["Attach to existing template group"]
    G -->|No| I["Create new template group"]

    H --> J["Representative message"]
    I --> J
```

## Python design

```python
def normalize_template(text: str) -> str:
    text = normalize_text(text)

    text = mask_email_addresses(text)
    text = mask_urls(text)
    text = mask_dates(text)
    text = mask_ids(text)
    text = mask_known_dynamic_patterns(text)

    return text
```

The implementation should be configurable by source/channel because Outlook, Bloomberg and Webex may have different dynamic fields.

---

# 10. Optional Step 5.5 — Lightweight Text Similarity

Do this only if measurements show template hashing is insufficient.

Example:

```text
A:
Please complete the insider trading compliance training.

B:
Please finish the required insider trading training.
```

They may not have the same template hash.

A lightweight library such as RapidFuzz can compare strings.

Conceptually:

```python
from rapidfuzz import fuzz

score = fuzz.token_set_ratio(text_a, text_b)
```

Potential routing:

```text
>= validated high threshold
    -> near-duplicate candidate

middle range
    -> do not automatically group

low similarity
    -> independent message
```

Do not choose thresholds such as 95% without validation. Build a labeled sample and measure precision/recall of duplicate grouping.

## Avoid O(N²)

Do not compare every message against every other message.

Use blocking/candidate generation such as:

```text
policy_id
+
message length bucket
+
selected normalized tokens
```

Only compare likely candidates.

---

# 11. Duplicate Group Data Model

A duplicate group should have one representative.

Example:

```text
DG-1001

Representative:
M001

Members:
M001
M002
M003
M004
M005
```

Suggested tables:

```text
duplicate_group
----------------------------
group_id
policy_id
representative_message_id
group_type
created_at

alert
----------------------------
alert_id
message_id
policy_id
channel
duplicate_group_id
is_representative
exact_hash
template_hash
```

Possible `group_type` values:

```text
EXACT
TEMPLATE
NEAR_TEXT
```

## Why one representative?

Only the representative needs to be sent to the LLM initially.

After classification:

```text
Representative M001
       |
       +--> M002
       +--> M003
       +--> M004
```

The decision can be associated with the duplicate group.

For conservative governance, the system should retain the relationship and allow a reviewer to inspect individual members.

---

# 12. Step 6 — Select Representative Messages

After duplicate reduction:

```text
Policy 1

Original = 200
Exact/template groups = 70
Representatives = 70
```

Instead of:

```text
200 LLM classifications
```

you may only need:

```text
70 classifications
```

The exact reduction should be measured from production data.

---

# 13. Step 7 — Context Extraction

This is one of the most important components.

Do not send the entire email/thread if you don't need it.

The LLM should receive enough context to make the policy decision.

## Preferred context

```text
Alert text
+
matched sentence/paragraph
+
previous sentence/paragraph
+
next sentence/paragraph
+
subject
```

Example:

```text
Alert:
insider trading

Previous:
I received confidential earnings information.

Matched:
You should buy shares before the announcement.

Next:
Please do not share this.
```

## Why surrounding context matters

The alert keyword alone can be misleading.

```text
"insider trading"
```

does not tell the LLM whether the communication is:

- training;
- news;
- policy discussion;
- investigation;
- actual suspicious activity.

---

# 14. Context Extraction Architecture

```mermaid
flowchart TD
    A["Representative Message"] --> B{"Alert offsets available?"}

    B -->|Yes| C["Use start/end offsets"]
    B -->|No| D["Find alert text occurrences"]

    C --> E["Identify matched sentence/paragraph"]
    D --> E

    E --> F["Extract previous context"]
    E --> G["Extract matched context"]
    E --> H["Extract next context"]

    F --> I["Context assembler"]
    G --> I
    H --> I

    I --> J["Add subject + alert text"]
    J --> K["Token budget check"]
    K --> L["Policy-ready message"]
```

---

# 15. Multiple Occurrences of Alert Text

Suppose:

```text
Paragraph 1:
Our insider trading policy requires training.

Paragraph 5:
This could be insider trading.

Paragraph 10:
Insider trading regulations are strict.
```

If the existing surveillance system does not tell you which occurrence triggered the alert, the extractor should return all relevant occurrences or score them using the configured trigger information.

Best solution:

Ask upstream to provide:

```text
alert_start_offset
alert_end_offset
```

If this is not possible:

```python
find_all_occurrences(
    full_message,
    alert_text
)
```

Then create a context candidate around each occurrence.

---

# 16. Long Messages

For very long email threads, use a progressive strategy.

```text
Level 1:
matched paragraph

Level 2:
matched paragraph + adjacent paragraphs

Level 3:
top relevant rule-based chunks

Level 4:
full message only when necessary
```

The initial implementation should avoid an embedding model.

A policy can optionally define additional keywords/phrases used to locate context.

Example:

```json
{
  "policy_id": "INSIDER_TRADING",
  "context_terms": [
    "confidential",
    "material non-public",
    "earnings",
    "buy",
    "sell",
    "trade",
    "announcement"
  ]
}
```

This is a deterministic context-expansion mechanism.

---

# 17. Step 8 — Policy Context

There are only ~50 policies, so policy management can remain simple.

Store policy configuration in a relational DB or version-controlled configuration.

Example:

```json
{
  "policy_id": "POLICY_001",
  "name": "Insider Trading",
  "version": "3",
  "description": "Detect communications potentially indicating use of material non-public information for trading.",
  "positive_indicators": [
    "confidential financial information",
    "instruction to trade",
    "buy before announcement",
    "sell before announcement"
  ],
  "negative_indicators": [
    "compliance training",
    "policy discussion",
    "educational content",
    "news discussion"
  ]
}
```

The policy context should be concise.

---

# 18. Step 9 — Token-Aware Batch Manager

This is where your original idea becomes very useful.

Suppose:

```text
Policy_1
100 unique messages
```

Do not make:

```text
100 API requests
```

Instead:

```text
Policy Context
+
Message 1
+
Message 2
+
...
```

until the configured token budget is reached.

## Important

Do not batch by:

```text
10 messages
20 messages
```

Batch by token budget.

Example:

```text
Model context = 32K

System instructions = 2K
Policy context = 2K
Reserved output = 4K

Available message budget = 24K
```

The batch manager keeps adding messages until approximately 24K input tokens are reached.

---

# 19. Batch Manager Architecture

```mermaid
flowchart TD
    A["Policy alerts"] --> B["Sort / queue representatives"]
    B --> C["Load policy context"]
    C --> D["Estimate message tokens"]
    D --> E{"Fits remaining token budget?"}

    E -->|Yes| F["Add message to batch"]
    F --> D

    E -->|No| G["Finalize batch"]
    G --> H["Send to LLM Gateway"]
    H --> I["Create next batch"]
    I --> D
```

Always leave safety margin because token estimates and output size can vary.

---

# 20. Step 10 — LLM Gateway

Do not tightly couple every Python worker to a specific model provider.

Create:

```text
Python worker
      |
      v
LLM Gateway
      |
      +-- Model A
      +-- Model B
      +-- Internal model
```

Responsibilities:

- authentication;
- model selection;
- rate limiting;
- retries;
- timeout;
- request logging;
- token metrics;
- cost metrics;
- structured output validation;
- provider fallback if approved.

Interface:

```python
class LLMGateway:

    async def classify(
        self,
        policy_context: dict,
        messages: list[dict]
    ) -> dict:
        ...
```

---

# 21. Step 11 — LLM Prompt

The LLM should be a **policy-aware classifier**, not a generic chatbot.

Conceptual prompt:

```text
SYSTEM

You are a surveillance alert classification assistant.

Determine whether each alert is:
TRUE_POSITIVE,
FALSE_POSITIVE,
or UNCERTAIN
with respect to the supplied surveillance policy.

Evaluate the actual meaning and context of the communication.

Do not classify based only on the presence of the alert keyword.

A communication discussing a prohibited activity, policy,
training, news, education, or investigation is not automatically
evidence of misconduct.

Use only evidence present in the supplied communication.

Return the required JSON schema.
```

Then:

```text
POLICY

Name:
Insider Trading

Definition:
...

Positive indicators:
...

Negative indicators:
...
```

Then:

```text
MESSAGES

[
  {
    "message_id": "M001",
    "alert_text": "insider trading",
    "context": "..."
  },
  {
    "message_id": "M002",
    "alert_text": "insider trading",
    "context": "..."
  }
]
```

---

# 22. Step 12 — Structured LLM Output

Recommended:

```json
{
  "results": [
    {
      "message_id": "M001",
      "classification": "FALSE_POSITIVE",
      "confidence": 0.96,
      "evidence": [
        "mandatory compliance training"
      ],
      "short_reason": "The message is about compliance training and does not indicate suspicious trading activity."
    },
    {
      "message_id": "M002",
      "classification": "TRUE_POSITIVE",
      "confidence": 0.88,
      "evidence": [
        "confidential earnings information",
        "buy before the announcement"
      ],
      "short_reason": "The communication appears to connect confidential information with a trading instruction."
    }
  ]
}
```

## Do not ask the model for hidden chain-of-thought

Use:

```text
evidence
short_reason
```

instead of a request for detailed internal reasoning.

This is cheaper, easier to audit and easier for reviewers to understand.

---

# 23. Step 13 — Result Validation

Never directly trust arbitrary LLM JSON.

Validate it using Pydantic.

```python
from enum import Enum
from pydantic import BaseModel


class Classification(str, Enum):
    TRUE_POSITIVE = "TRUE_POSITIVE"
    FALSE_POSITIVE = "FALSE_POSITIVE"
    UNCERTAIN = "UNCERTAIN"


class AIResult(BaseModel):
    message_id: str
    classification: Classification
    confidence: float
    evidence: list[str]
    short_reason: str
```

Validate:

```text
message_id exists
classification valid
confidence between 0 and 1
evidence is list
reason exists
```

If validation fails:

```text
retry / repair request / mark technical failure
```

---

# 24. Step 14 — Decision Routing

Do not immediately equate:

```text
confidence = 0.95
```

with:

```text
95% probability of correctness
```

LLM confidence should initially be treated as a model output signal that needs calibration.

Start with:

```text
TRUE_POSITIVE
FALSE_POSITIVE
UNCERTAIN
```

and configurable policy thresholds.

Example:

```json
{
  "policy_id": "POLICY_001",
  "human_review_threshold": 0.90,
  "candidate_fp_threshold": 0.98
}
```

But thresholds must be validated against human-labeled results.

---

# 25. Human Review

The business reviewer should see:

```text
Alert ID
Policy
Channel
Original alert text
Relevant context
AI classification
AI confidence
Evidence
Short reason
Duplicate group
```

The reviewer then chooses:

```text
TRUE_POSITIVE
FALSE_POSITIVE
NEEDS_MORE_REVIEW
```

This human decision becomes valuable feedback.

---

# 26. Step 15 — Duplicate Result Propagation

If:

```text
M001
M002
M003
```

are confirmed as one duplicate group and M001 is classified:

```text
FALSE_POSITIVE
```

the system can associate the AI decision with the group.

However, retain:

```text
representative_message_id
duplicate_group_id
```

so reviewers can inspect the original members.

For sensitive policies, group-level propagation can be configured conservatively.

---

# 27. Step 16 — Database Design

Recommended core tables:

```text
policy
alert
duplicate_group
ai_batch
ai_decision
human_review
model_version
prompt_version
audit_event
```

## policy

```text
policy_id
name
description
version
configuration_json
active
created_at
updated_at
```

## alert

```text
alert_id
message_id
policy_id
channel
alert_text
message_hash
template_hash
duplicate_group_id
is_representative
message_timestamp
created_at
```

## duplicate_group

```text
group_id
policy_id
group_type
representative_alert_id
member_count
created_at
```

## ai_batch

```text
batch_id
policy_id
model_name
prompt_version
input_tokens
output_tokens
status
created_at
completed_at
```

## ai_decision

```text
decision_id
batch_id
alert_id
classification
confidence
evidence_json
short_reason
created_at
```

## human_review

```text
review_id
alert_id
reviewer_id
final_classification
review_comment
reviewed_at
```

---

# 28. Step 17 — Asynchronous Processing

At 1M/day:

```text
1,000,000 / 86,400
≈ 11.6 alerts/sec average
```

Average throughput is manageable, but peak volume can be significantly higher.

Use an asynchronous queue/stream if your enterprise environment already supports one.

Example:

```mermaid
flowchart LR
    A["Existing Surveillance"] --> B["Kafka / Enterprise Queue"]

    B --> C1["Normalizer Worker"]
    B --> C2["Normalizer Worker"]
    B --> C3["Normalizer Worker"]

    C1 --> D["Processing Topics"]
    C2 --> D
    C3 --> D

    D --> E1["Policy Worker"]
    D --> E2["Policy Worker"]
    D --> E3["Policy Worker"]

    E1 --> F["LLM Gateway"]
    E2 --> F
    E3 --> F

    F --> G["Results Topic"]
    G --> H["Results DB"]
```

This lets you scale workers horizontally.

---

# 29. Step 18 — Python Service Structure

Suggested repository:

```text
false-positive-detection/
│
├── README.md
├── docs/
│   ├── architecture.md
│   ├── llm-design.md
│   ├── duplicate-detection.md
│   └── context-extraction.md
│
├── diagrams/
│   ├── architecture.mmd
│   ├── sequence.mmd
│   ├── duplicate-detection.mmd
│   └── context-extraction.mmd
│
├── src/
│   ├── domain/
│   │   ├── models.py
│   │   └── policies.py
│   │
│   ├── ingestion/
│   │   └── consumer.py
│   │
│   ├── normalization/
│   │   └── normalizer.py
│   │
│   ├── duplicate_detection/
│   │   ├── exact.py
│   │   ├── template.py
│   │   └── similarity.py
│   │
│   ├── context_extraction/
│   │   ├── locator.py
│   │   ├── extractor.py
│   │   └── optimizer.py
│   │
│   ├── batching/
│   │   ├── token_counter.py
│   │   └── batch_manager.py
│   │
│   ├── llm/
│   │   ├── gateway.py
│   │   ├── prompt_builder.py
│   │   └── validator.py
│   │
│   ├── decision/
│   │   └── router.py
│   │
│   └── persistence/
│       ├── repositories.py
│       └── models.py
│
└── tests/
```

---

# 30. Step 19 — End-to-End Processing Sequence

```mermaid
sequenceDiagram
    participant SS as Surveillance System
    participant ING as Ingestion
    participant N as Normalizer
    participant D as Duplicate Detector
    participant C as Context Extractor
    participant B as Batch Manager
    participant G as LLM Gateway
    participant L as LLM
    participant DB as Results DB
    participant H as Human Reviewer

    SS->>ING: Alert event
    ING->>N: Raw alert
    N->>D: Canonical alert

    D->>D: Exact hash
    D->>D: Template normalization/hash

    alt Duplicate
        D->>DB: Store duplicate relationship
    else Representative
        D->>C: Representative alert
        C->>C: Locate alert text
        C->>C: Extract surrounding context
        C->>B: Policy-ready message
        B->>B: Add to token-aware batch
    end

    B->>G: Policy + batch
    G->>L: Classification request
    L-->>G: Structured JSON
    G->>DB: Store AI decisions

    DB-->>H: Low-confidence cases
    H->>DB: Human decision
    DB->>DB: Update metrics/audit
```

---

# 31. Step 20 — Cost Optimization

The cost optimization hierarchy should be:

```text
1. Don't send duplicate alerts
2. Don't send unnecessary message content
3. Batch multiple messages
4. Reuse stable policy/system context where provider supports caching
5. Use an appropriate model
6. Measure tokens and continuously optimize
```

Avoid starting with complex ML infrastructure.

Example:

```text
1,000 alerts
      |
      | exact/template dedup
      v
300 representatives
      |
      | context extraction
      v
300 compact messages
      |
      | batch
      v
10-20 LLM requests
```

Actual numbers depend on your data.

---

# 32. Step 21 — Why No Embeddings Initially

The architecture intentionally excludes embeddings.

Reasons:

1. Additional model inference.
2. Additional infrastructure.
3. Vector storage/search.
4. Similarity threshold tuning.
5. Semantic similarity does not necessarily mean same surveillance outcome.
6. The final LLM already provides semantic understanding.
7. Exact/template deduplication is deterministic and easier to audit.
8. Production measurements can later justify adding a semantic layer.

Potential future architecture:

```text
Human review data
       |
       v
Measure remaining duplicate patterns
       |
       v
If deterministic methods are insufficient
       |
       v
Evaluate ML/embedding optimization
```

Do not add it before there is a measurable benefit.

---

# 33. Step 22 — Monitoring and Metrics

The system needs operational and quality metrics.

## Volume

```text
total alerts
alerts per policy
alerts per channel
exact duplicate count
template duplicate count
representative count
LLM processed count
human review count
```

## AI quality

```text
AI FP precision
AI TP precision
False negative rate
Human/AI agreement
Uncertain percentage
```

## Performance

```text
processing throughput
LLM latency
p50/p95/p99 latency
queue depth
retry count
LLM failure rate
```

## Cost

```text
input tokens
output tokens
tokens/alert
LLM calls/day
cost/day
cost/1,000 alerts
```

---

# 34. Step 23 — Human Feedback Loop

This is the long-term improvement mechanism.

```mermaid
flowchart LR
    A["AI Classification"] --> B["Business Review"]
    B --> C["Final Human Decision"]
    C --> D["Feedback Dataset"]

    D --> E["Analyze AI Errors"]
    E --> F["Improve"]
    F --> G["Prompt"]
    F --> H["Context Extraction"]
    F --> I["Duplicate Rules"]
    F --> J["Thresholds"]

    G --> A
    H --> A
    I --> A
    J --> A
```

After enough data, you can evaluate whether a lightweight classifier would provide further savings.

---

# 35. Step 24 — Security and Privacy

Because surveillance communications can contain sensitive information:

- encrypt data at rest;
- encrypt traffic in transit;
- minimize stored raw content;
- apply role-based access;
- audit access to communications;
- avoid putting sensitive content in application logs;
- use approved enterprise LLM endpoints;
- validate provider data-retention policies;
- use secrets management;
- separate production credentials;
- retain model/prompt version information.

Do not log the entire email body in normal application logs.

Instead:

```text
alert_id
message_id
policy_id
batch_id
status
latency
token counts
```

---

# 36. Step 25 — Failure Handling

LLM failure should not cause the surveillance system to lose alerts.

Example:

```mermaid
flowchart TD
    A["Batch"] --> B["LLM Gateway"]
    B --> C{"Successful?"}

    C -->|Yes| D["Validate JSON"]
    C -->|No| E["Retry with backoff"]

    E --> F{"Retry limit reached?"}
    F -->|No| B
    F -->|Yes| G["Dead-letter / retry queue"]

    D --> H{"Valid schema?"}
    H -->|Yes| I["Persist result"]
    H -->|No| J["Repair / retry"]
    J --> F
```

Original alerts should remain available even if the AI service is unavailable.

---

# 37. Step 26 — Important Governance Rule

The AI layer should initially be considered a **decision-support / triage system**, not the authoritative compliance decision maker.

Recommended initial states:

```text
AI_FALSE_POSITIVE_RECOMMENDATION
AI_TRUE_POSITIVE_RECOMMENDATION
AI_UNCERTAIN
TECHNICAL_FAILURE
```

The business process can determine whether/when a recommendation is sufficient for suppression.

---

# 38. Final Recommended Architecture

```mermaid
flowchart TB

    subgraph SOURCES["Communication & Existing Surveillance"]
        A1["Outlook"]
        A2["Webex"]
        A3["Bloomberg"]
        A4["Other Channels"]
        S["Existing Surveillance Engine"]
        A1 --> S
        A2 --> S
        A3 --> S
        A4 --> S
    end

    S --> ING["Alert Ingestion"]

    subgraph PRE["Pre-LLM Reduction"]
        N["Canonical Alert Normalizer"]
        P["Group by Policy"]
        X["Exact Duplicate<br/>Normalized SHA-256"]
        T["Template Duplicate<br/>Dynamic Value Masking + Hash"]
        R["Optional Near Text Similarity<br/>RapidFuzz"]
        REP["Representative Alerts"]

        ING --> N
        N --> P
        P --> X
        X --> T
        T --> R
        R --> REP
    end

    subgraph CONTEXT["Context Preparation"]
        CE["Alert Location / Context Extractor"]
        CO["Context Optimizer"]
        BM["Token-Aware Batch Manager"]

        REP --> CE
        CE --> CO
        CO --> BM
    end

    subgraph AI["AI Classification"]
        G["LLM Gateway"]
        L["Policy-Aware LLM"]
        V["Structured Output Validator"]

        BM --> G
        G --> L
        L --> V
    end

    subgraph DECISION["Decision & Review"]
        D["Decision Router"]
        FP["FP Recommendation"]
        TP["TP Priority Review"]
        UR["Uncertain / Low Confidence"]
        UI["Business Review UI"]
        HR["Human Decision"]

        V --> D
        D --> FP
        D --> TP
        D --> UR
        UR --> UI
        UI --> HR
    end

    subgraph DATA["Persistence & Governance"]
        DB["Results / Audit DB"]
        M["Metrics & Monitoring"]
        CFG["Policy / Prompt / Model Configuration"]

        FP --> DB
        TP --> DB
        HR --> DB
        V --> DB
        DB --> M
        CFG --> BM
        CFG --> G
        CFG --> L
    end

    M -. "Improve thresholds / prompts / rules" .-> CFG
```

---

# 39. Recommended Technology Stack

| Area | Initial recommendation |
|---|---|
| Language | Python |
| API/service | FastAPI |
| Validation | Pydantic |
| Async processing | asyncio |
| Queue | Kafka or existing enterprise queue |
| Database | PostgreSQL / existing enterprise RDBMS |
| Cache | Redis, optional |
| Exact duplicate | SHA-256 |
| Template duplicate | Regex + normalization + hash |
| Optional near duplicate | RapidFuzz |
| Semantic embeddings | **Not initially used** |
| LLM | Approved enterprise LLM API |
| LLM abstraction | Internal LLM Gateway |
| Deployment | Docker + Kubernetes |
| Monitoring | Existing enterprise observability stack |
| Secrets | Enterprise secret manager |

---

# 40. Recommended Implementation Phases

## Phase 1 — POC

Build:

```text
Alert
 -> Policy
 -> Exact duplicate
 -> Template duplicate
 -> Context extraction
 -> LLM
 -> JSON result
```

Use a representative historical dataset.

Measure:

```text
duplicate reduction
LLM token reduction
AI vs human agreement
```

## Phase 2 — Production MVP

Add:

```text
queue
workers
LLM gateway
DB
audit
business review
metrics
retry/DLQ
```

## Phase 3 — Optimization

Use real production measurements to optimize:

```text
context size
duplicate rules
batch size
model choice
thresholds
prompt
```

## Phase 4 — Advanced Optimization

Only if justified by data:

```text
lightweight classifier
specialized models
additional semantic optimization
```

Embeddings/vector search remain optional rather than mandatory.

---

# 41. The Key Architecture Decision

The most important design principle for this project is:

> **Use deterministic and inexpensive processing to reduce the workload; use the LLM only for the part that actually requires semantic understanding.**

Therefore:

```text
               CHEAP / DETERMINISTIC
                       │
        ┌──────────────┼──────────────┐
        │              │              │
    Normalize       Duplicate      Context
        │              │          extraction
        └──────────────┼──────────────┘
                       │
                       ▼
                REDUCED ALERT SET
                       │
                       ▼
                 EXPENSIVE / SMART
                       │
                       ▼
                      LLM
                       │
                       ▼
              HUMAN VALIDATION
```

This is the architecture I would recommend presenting as the **initial production solution**.
