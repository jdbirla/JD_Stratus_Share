# Implementation Blueprint

## Suggested Python modules

```text
src/
├── domain/
│   ├── models.py
│   └── enums.py
├── ingestion/
│   └── consumer.py
├── normalization/
│   ├── normalizer.py
│   └── html_cleaner.py
├── duplicate_detection/
│   ├── exact.py
│   ├── dynamic_masker.py
│   ├── template.py
│   └── similarity.py
├── context_extraction/
│   ├── locator.py
│   ├── paragraph_splitter.py
│   ├── extractor.py
│   └── optimizer.py
├── batching/
│   ├── token_counter.py
│   └── batch_manager.py
├── llm/
│   ├── gateway.py
│   ├── prompt_builder.py
│   └── response_validator.py
├── decision/
│   └── router.py
└── persistence/
    ├── repositories.py
    └── models.py
```

## Core processing contract

```python
async def process_alert(alert: Alert) -> None:
    normalized = normalize(alert)

    duplicate = duplicate_detector.find_or_create(normalized)

    if duplicate.is_duplicate:
        await repository.save_duplicate_relationship(
            alert,
            duplicate.group_id
        )
        return

    context = context_extractor.extract(
        normalized.full_message,
        normalized.alert_text,
        normalized.alert_start_offset,
        normalized.alert_end_offset,
    )

    await batch_manager.add(
        policy_id=normalized.policy_id,
        message={
            "message_id": normalized.message_id,
            "alert_text": normalized.alert_text,
            "context": context,
        }
    )
```

## Batch processing

```python
async def flush_policy_batch(policy_id: str, messages: list[dict]):
    policy = policy_repository.get(policy_id)

    response = await llm_gateway.classify(
        policy_context=policy,
        messages=messages,
    )

    results = response_validator.validate(response)

    await decision_repository.save(results)
```

## Important engineering rules

### Do not block ingestion on LLM calls

Use asynchronous queues.

### Do not log raw communication content

Log identifiers, status, timing and token metrics.

### Make every AI decision reproducible

Store:

- model name/version
- prompt version
- policy version
- batch ID
- timestamp
- input token count
- output token count

### Make duplicate grouping reversible

Never delete duplicate alerts. Mark their relationship.

### Make thresholds configurable

Do not hard-code business thresholds.

### Make LLM provider replaceable

Use an internal interface rather than provider-specific calls throughout the application.
