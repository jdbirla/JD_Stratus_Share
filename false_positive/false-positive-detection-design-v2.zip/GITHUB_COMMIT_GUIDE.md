# GitHub Usage

The repository contains the architecture documentation and Mermaid diagrams.

## Structure

```text
false-positive-detection/
├── README.md
├── docs/
│   └── implementation-blueprint.md
└── diagrams/
    ├── 01-end-to-end.mmd
    ├── 02-duplicate-detection.mmd
    ├── 03-context-extraction.mmd
    ├── 04-batching.mmd
    ├── 05-llm-sequence.mmd
    ├── 06-human-feedback.mmd
    └── 07-deployment.mmd
```

GitHub renders Mermaid diagrams inside Markdown files. To embed one:

```mermaid
flowchart TD
    A --> B
```

Suggested commit:

```bash
git add README.md docs/ diagrams/
git commit -m "docs: add surveillance false-positive detection architecture"
git push
```

The architecture intentionally excludes embeddings/vector search from the initial production design.
